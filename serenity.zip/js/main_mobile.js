$('.11').on('click',function(){
  console.log("1");
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('one');
});
$('#curve-22').on('click',function(){
   console.log("2");
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('two');
});
$('#curve-33').on('click',function(){
   console.log("3");
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('three');
});
$('#curve-44').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('four');
});
$('#curve-55').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('five');
});
$('#curve-66').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('six');
});
$('#curve-77').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('seven');
});
$('#curve-88').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('eight');
});
$('#curve-99').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('nine');
});
$('#curve-1010').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('ten');
});
$('#curve-1111').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('eleven');
});
$('#curve-1212').on('click',function(){
  $('.wrapper').removeClass('one two three four five six seven eight nine ten eleven twelve');
  $('.wrapper').addClass('twelve');
});